<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'XS8UP+UAk/unteBOZrVJqWCoLLV1+eYuR4sID2n+sFXfzXIac4olcA44GqeXJoBSLNVKcW7gbXNegsGhFs9xYA==');
define('SECURE_AUTH_KEY',  'TqXXyvhr6lapdBEsxC3rxHftMD411VIype8aOBkxQAfCc3kPi0rWWUb47z0w+mo2k6V4nhnn1/t4AtCM3i4FsA==');
define('LOGGED_IN_KEY',    '54LWe/PJfwQzPnClR9vv8kMbZyvBI8xVo5+1eI4C3AdRMr2fn2NMNzW04at3Q7965AUI4FAFU/nY21E3skivlQ==');
define('NONCE_KEY',        'MYOB4tdxCQ60xWQis3FRN0HfmyiuqWfe2ECevoQsKlaqWWPM0UNjW6ywsAuKdu2DXny5s9omgDQDH++cLtqewQ==');
define('AUTH_SALT',        'QbMdU2TkmLiYyhtEq/rqmoi+ugM/MRwsIC/xlPfSLeUgWpPeV6PciKralHWVxxCjY3ITmEAydIuO/JfaoY5Umw==');
define('SECURE_AUTH_SALT', 'f6jDhQuVUvvf4E5G4AcbAd6cejUVcGzdyN8HNGKLEsqaZAR1H0nhEMIam8PTGF37Xfsc3lxstzt7vDH9gRipbA==');
define('LOGGED_IN_SALT',   'Tzlj12i3K/O1RxILYEMimaCH60xLvTtdGyr8/cIwNHUGeNa85lC8Tfw0LOshsAVf3XxSEZ0QC+qlWF0k6q9x1A==');
define('NONCE_SALT',       '/+eUSyH5v+IcymUhJHGSxBu44XWLuQjNR6yi14/4M3FWz1nnegGCx1ei8U8rZwnQWvR8MVcxgVnAxK29KXutkA==');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
