import "../../../styles/global/lazy-load/global.scss";

console.log("this is the lazy-loading part of the global script!!!");