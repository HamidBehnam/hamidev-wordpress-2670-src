import "../../../styles/single/lazy-load/single.scss";

console.log("this is the lazy part of the single!");