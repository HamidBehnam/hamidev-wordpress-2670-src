import "../../../styles/single/eager-load/single.scss";

console.log("this is the eager module for the single pages.");

setTimeout(async () => {
    await import(/* webpackChunkName: "single-lazy" */ '../lazy-load/single');
}, 5000);