import "../../../styles/page/lazy-load/page.scss";

console.log("this is the lazy part of the page script!");